lazy_static::lazy_static! {
pub static ref T: std::collections::HashMap<&'static str, &'static str> =
    [
        ("desk_tip", "Your desktop can be accessed with this ID and password."),
        ("connecting_status", "Connecting to the HopToDesk network..."),
        ("not_ready_status", "Not ready. Please check your connection"),
        ("id_change_tip", "Only a-z, A-Z, 0-9 and _ (underscore) characters allowed. The first letter must be a-z, A-Z. Length between 6 and 16."),
        ("install_tip", "For best performance, complete a full install."),
        ("config_acc", "Enable the \"Accessibility\" permission to use screen share."),
        ("config_screen", "Enable \"Screen Recording\" permissions to use screen share."),
        ("agreement_tip", "By starting the installation, you accept the license agreement."),
        ("not_close_tcp_tip", "Don't close this window while you are using the tunnel"),
        ("setup_server_tip", "For faster connection, please set up your own server"),
        ("Auto Login", "Auto Login (Only valid if you set \"Lock after session end\")"),
        ("whitelist_tip", "Only whitelisted IP can access me"),
        ("whitelist_sep", "Seperated by comma, semicolon, spaces or new line"),
        ("Wrong credentials", "Wrong username or password"),
        ("invalid_http", "must start with http:// or https://"),
        ("install_daemon_tip", "For starting on boot, you need to install system service."),
        ("android_input_permission_tip1", "After obtaining the input permission, the remote device can control this Android device by mouse"),
        ("android_input_permission_tip2", "Please go to the next system settings page,find and enter [Installed Services],turn [HopToDesk Input] service ON"),
        ("android_new_connection_tip", "New control request has been received,it want to control your current device."),
        ("android_service_will_start_tip", "Turning on the Screen Capture will automatically start the service,allowing other devices to request a connection from this device."),
        ("android_stop_service_tip", "Closing the service will automatically close all established connections."),
        ("android_version_audio_tip", "The current Android version does not support audio capture, please Upgrade Now to Android 10 or higher."),
        ("android_start_service_tip", "Tap [Start Service] or OPEN [Screen Capture] permission to start the screen sharing service."),
    ].iter().cloned().collect();
}
